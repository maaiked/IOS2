//
//  JsonObjectEnt+CoreDataProperties.swift
//  Werkstuk2
//
//  Created by Maaike Dupont on 01/06/2019.
//  Copyright © 2019 Maaike Dupont. All rights reserved.
//
//

import Foundation
import CoreData


extension JsonObjectEnt {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<JsonObjectEnt> {
        return NSFetchRequest<JsonObjectEnt>(entityName: "JsonObjectEnt")
    }

    @NSManaged public var recordRel: NSSet?

}

// MARK: Generated accessors for recordRel
extension JsonObjectEnt {

    @objc(addRecordRelObject:)
    @NSManaged public func addToRecordRel(_ value: RecordEnt)

    @objc(removeRecordRelObject:)
    @NSManaged public func removeFromRecordRel(_ value: RecordEnt)

    @objc(addRecordRel:)
    @NSManaged public func addToRecordRel(_ values: NSSet)

    @objc(removeRecordRel:)
    @NSManaged public func removeFromRecordRel(_ values: NSSet)

}
