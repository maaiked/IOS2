//
//  MapViewController.swift
//  Werkstuk2
//
//  Created by Maaike Dupont on 30/05/2019.
//  Copyright © 2019 Maaike Dupont. All rights reserved.
//
// Met veel dank aan Stackoverflow en Youtube ( heel veel getest, gewijzigd en geprobeerd door elkaar)

import UIKit
import MapKit
import CoreLocation
import CoreData
import Foundation

class MapViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    // MARK : props : managedContext
    lazy var managedContext = appDelegate.persistentContainer.viewContext
    
    //extra struct for array
    struct JsonObject: Codable {
        
        let records: [Record]
        
        enum CodingKeys: String, CodingKey {
            case records = "records"
        }
        init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            self.records = try container.decode([Record].self, forKey: .records)
        }
        func encode(to encoder: Encoder) throws {
            var container = encoder.container(keyedBy: CodingKeys.self)
            try container.encode(self.records, forKey: .records)
        }
    
    }
    
    // Codable code
    struct Record: Codable {
        // props
        let coordinates : [[Double]]
        //coding keys
        enum CodingKeys: String, CodingKey {
            case fields = "fields"
            case coordinates = "coordinates"
            case geoshape = "geo_shape"
        }
        
        
        //decoding
        init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            
            let fields = try container.nestedContainer(keyedBy: CodingKeys.self, forKey: .fields)
            let geoshape = try fields.nestedContainer(keyedBy: CodingKeys.self, forKey: .geoshape)
            coordinates = try geoshape.decode(Array.self, forKey: .coordinates)
            //save(coordinates: coordinates)
        }
        
        func encode (to encoder: Encoder) throws
        {
            var container = encoder.container(keyedBy: CodingKeys.self)
            var fields = container.nestedContainer(keyedBy: CodingKeys.self, forKey: .fields)
            var geoshape = fields.nestedContainer(keyedBy: CodingKeys.self, forKey: .geoshape)
            try geoshape.encode(coordinates, forKey: .coordinates)
        }
    }
    
    // MARK : properties
    
    @IBAction func updateButton(_ sender: UIButton) {
        makeGetCall()
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "dd/MM/yyyy hh:mm:ss"
        labelDatumBijgewerkt.text = dateformatter.string(from: Date())
       drawPolyLines()
    }
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var labelDatumBijgewerkt: UILabel!
    
    var locationManager = CLLocationManager()
    
    // MARK : viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
       
        if self.entityIsEmpty(entity: "CoordEnt") {
            self.makeGetCall()
        }
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
        
        drawPolyLines()
        
        // Do any additional setup after loading the view.
     
        //format date into label
        let dateRefreshed = fetchDate()
        
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "dd/MM/yyyy hh:mm:ss"
        labelDatumBijgewerkt.text = dateformatter.string(from: dateRefreshed)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK : functions
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        let center = CLLocationCoordinate2D(latitude: userLocation.coordinate.latitude, longitude: userLocation.coordinate.longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
        mapView.setRegion(region, animated: true)
    }
    
    func drawPolyLines(){
        let coordinatesArray = fetchCoordinates()
        for coord in coordinatesArray as [CoordEnt]
        {
            var coordTestArray = [CLLocationCoordinate2D]()
            for doubles in coord.doubleRel!
            {
                let double = doubles as! DoubleEnt
                let coordTest = CLLocationCoordinate2D(latitude: double.latitude, longitude: double.longitude)
                coordTestArray.append(coordTest)
            }

            let polylineTest = MKPolyline(coordinates:coordTestArray, count: coordTestArray.count)
            mapView.add(polylineTest)
            
        }
        /*
        for pnt in pointsArray
        {
            let polyline = MKPolyline(points: pnt, count: pnt.count)
            mapView.add(polyline)
        }
        */
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer
    {
        if let polyline = overlay as? MKPolyline
        {
            let lineView = MKPolylineRenderer(polyline: polyline)
            lineView.strokeColor = UIColor.red
            lineView.lineWidth = CGFloat(3)
            return lineView
        }
        return MKOverlayRenderer()
    }
    
    func makeGetCall(){
        
        let url = URL(string: "https://opendata.brussels.be/api/records/1.0/search/?dataset=traffic-volume&rows=70")
        let urlRequest = URLRequest(url: url!)
        
        let session = URLSession(configuration: URLSessionConfiguration.default)
        let task = session.dataTask(with: urlRequest) {
            (data, response, error) in
            guard error == nil else {
                print("error calling GET")
                print(error!)
                return
            }
            guard let responseData = data else {
                print("Error: did not receive data")
                return
            }
            // parse result
            do {
                guard let trafficdata = try? JSONDecoder().decode(JsonObject.self, from: responseData)
                
                    else {
                    print("error trying to convert data to JSON")
                    return
                }
                
                // delete all coordinates object
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CoordEnt")
                fetchRequest.includesPropertyValues = false
                do {
                    let items = try self.managedContext.fetch(fetchRequest) as! [NSManagedObject]
                    for item in items {
                        self.managedContext.delete(item)
                    }
                    try self.managedContext.save()
                }
                catch {
                    fatalError("failure to delete objects from core data")
                }
                //delete date object
                let fetchDateRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "DateEnt")
                fetchDateRequest.includesPropertyValues = false
                do {
                    let items = try self.managedContext.fetch(fetchDateRequest)
                    as! [NSManagedObject]
                    for item in items {
                        self.managedContext.delete(item)
                    }
                    try self.managedContext.save()
                }
                catch { fatalError("Failure to delete date objects from core data")}
                
                
                DispatchQueue.main.async {
                    // pass data to coredata
                    for rec in trafficdata.records
                    {
                        let coordinaat = NSEntityDescription.insertNewObject(forEntityName: "CoordEnt", into: self.managedContext) as! CoordEnt
                        
                        for coor in rec.coordinates {
                            
                            let doubleData = NSEntityDescription.insertNewObject(forEntityName: "DoubleEnt", into: self.managedContext) as! DoubleEnt
                            
                            // ad doubledata to coordinateEntity
                            doubleData.latitude = coor[0]
                            doubleData.longitude = coor[1]
                            coordinaat.addToDoubleRel(doubleData)
                            
                            do{ try self.managedContext.save()
                                print ("save gelukt")
                            }
                            catch { fatalError("save niet gelukt")}
                        }
                    
                    }  //forloop ended
                    let bijgewerktData = NSEntityDescription.insertNewObject(forEntityName: "DateEnt", into: self.managedContext) as! DateEnt
                    bijgewerktData.datumBijgewerkt = Date()
                    do {
                        try self.managedContext.save()
                        print ("datum gesaved")
                    }
                    catch { fatalError("save datum niet gelukt")}
                }
            }
        }
        task.resume()
        } // end func makeGetCall
    
    func fetchDate() -> Date {
        //fetch date refreshed
        var datumRefresh = Date()
        let fetchDateRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "DateEnt")
        fetchDateRequest.includesPropertyValues = false
        do {
            let items = try self.managedContext.fetch(fetchDateRequest)
                as! [DateEnt]
            for item in items as [DateEnt] {
                datumRefresh = item.datumBijgewerkt! as Date
            }
            return datumRefresh as Date
        }
        catch { fatalError("Failure to fetch date objects from core data")}
        
    } // end func fetchDate
    
    
    func fetchCoordinates() -> [CoordEnt]{
        //fetch coordinate entities
        let coordinateEntity = NSFetchRequest<NSFetchRequestResult>(entityName: "CoordEnt")
        let opgehaaldeCoordinaten:[CoordEnt]
        var aantal = 1
        do {
            opgehaaldeCoordinaten = try self.managedContext.fetch(coordinateEntity) as! [CoordEnt]
            print("coordinaten")
            for coords in opgehaaldeCoordinaten as [CoordEnt] {
                print ("------COORD--------")
                print (aantal)
                print ("-------------------")
                for doublesData in coords.doubleRel!{
                    let doubleData = doublesData as! DoubleEnt
                    print (doubleData.latitude)
                    print (doubleData.longitude)
                }
                aantal += 1
            }
        }
        catch { fatalError("fetch niet gelukt")}
        return opgehaaldeCoordinaten
    }

    // end func fetchCoordinates
    
    //check if core data is empty : stackoverflow
    func entityIsEmpty(entity: String) -> Bool {
        do {
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
            let count = try managedContext.count(for: request)
            print (count)
            return count == 0 ? true : false
        }
        catch {
            return true
        }
    } // end func entityIsEmpty

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

