//
//  DoubleEnt+CoreDataProperties.swift
//  Werkstuk2
//
//  Created by Maaike Dupont on 02/06/2019.
//  Copyright © 2019 Maaike Dupont. All rights reserved.
//
//

import Foundation
import CoreData


extension DoubleEnt {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<DoubleEnt> {
        return NSFetchRequest<DoubleEnt>(entityName: "DoubleEnt")
    }

    @NSManaged public var longitude: Double
    @NSManaged public var latitude: Double

}
