//
//  DoubleEnt+CoreDataClass.swift
//  Werkstuk2
//
//  Created by Maaike Dupont on 01/06/2019.
//  Copyright © 2019 Maaike Dupont. All rights reserved.
//
//

import Foundation
import CoreData

@objc(DoubleEnt)
public class DoubleEnt: NSManagedObject {

}
