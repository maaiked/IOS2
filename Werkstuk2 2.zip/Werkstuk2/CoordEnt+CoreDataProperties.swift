//
//  CoordEnt+CoreDataProperties.swift
//  Werkstuk2
//
//  Created by Maaike Dupont on 02/06/2019.
//  Copyright © 2019 Maaike Dupont. All rights reserved.
//
//

import Foundation
import CoreData


extension CoordEnt {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CoordEnt> {
        return NSFetchRequest<CoordEnt>(entityName: "CoordEnt")
    }

    @NSManaged public var doubleRel: NSSet?

}

// MARK: Generated accessors for doubleRel
extension CoordEnt {

    @objc(addDoubleRelObject:)
    @NSManaged public func addToDoubleRel(_ value: DoubleEnt)

    @objc(removeDoubleRelObject:)
    @NSManaged public func removeFromDoubleRel(_ value: DoubleEnt)

    @objc(addDoubleRel:)
    @NSManaged public func addToDoubleRel(_ values: NSSet)

    @objc(removeDoubleRel:)
    @NSManaged public func removeFromDoubleRel(_ values: NSSet)

}
