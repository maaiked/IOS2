//
//  Coordinates+CoreDataProperties.swift
//  Werkstuk2
//
//  Created by Maaike Dupont on 01/06/2019.
//  Copyright © 2019 Maaike Dupont. All rights reserved.
//
//

import Foundation
import CoreData


extension Coordinates {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Coordinates> {
        return NSFetchRequest<Coordinates>(entityName: "Coordinates")
    }

    @NSManaged public var doubleRel: NSSet?

}

// MARK: Generated accessors for doubleRel
extension Coordinates {

    @objc(addDoubleRelObject:)
    @NSManaged public func addToDoubleRel(_ value: Double)

    @objc(removeDoubleRelObject:)
    @NSManaged public func removeFromDoubleRel(_ value: Double)

    @objc(addDoubleRel:)
    @NSManaged public func addToDoubleRel(_ values: NSSet)

    @objc(removeDoubleRel:)
    @NSManaged public func removeFromDoubleRel(_ values: NSSet)

}
