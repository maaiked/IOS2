//
//  JsonObject+CoreDataProperties.swift
//  Werkstuk2
//
//  Created by Maaike Dupont on 01/06/2019.
//  Copyright © 2019 Maaike Dupont. All rights reserved.
//
//

import Foundation
import CoreData


extension JsonObject {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<JsonObject> {
        return NSFetchRequest<JsonObject>(entityName: "JsonObject")
    }

    @NSManaged public var recordRel: NSSet?

}

// MARK: Generated accessors for recordRel
extension JsonObject {

    @objc(addRecordRelObject:)
    @NSManaged public func addToRecordRel(_ value: Record)

    @objc(removeRecordRelObject:)
    @NSManaged public func removeFromRecordRel(_ value: Record)

    @objc(addRecordRel:)
    @NSManaged public func addToRecordRel(_ values: NSSet)

    @objc(removeRecordRel:)
    @NSManaged public func removeFromRecordRel(_ values: NSSet)

}
