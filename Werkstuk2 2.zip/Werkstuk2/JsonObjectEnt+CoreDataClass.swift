//
//  JsonObjectEnt+CoreDataClass.swift
//  Werkstuk2
//
//  Created by Maaike Dupont on 01/06/2019.
//  Copyright © 2019 Maaike Dupont. All rights reserved.
//
//

import Foundation
import CoreData

extension CodingUserInfoKey{
    static let context = CodingUserInfoKey(rawValue: "context")
}

@objc(JsonObjectEnt)
public class JsonObjectEnt: NSManagedObject, Codable {
    public func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.Self)
        do {
            // try (container.encode(car, forKey: .car) ?? nil)
        }
        catch { print("error")}
    }
    

}
